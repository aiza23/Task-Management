import React, { FunctionComponent } from 'react';
import { useState } from 'react';
import './App.css';
import addLogo from './img/add.png';

/*
const Counter2:FunctionComponent<{ taskiditem?: string,tasktextitem?: string}>=({taskiditem,tasktextitem}) => {
  const[ids,setIDs] = useState(taskiditem);
  const[tasks,setTasks] = useState(tasktextitem);

  return<>
    <form>
        <input type="text" id="taskiditem" name="taskiditem" placeholder="Task ID"></input>
        <input type="text" id="tasktextitem" name="tasktextitem" placeholder="Tasks"></input>
        <button onClick={() => alert("erm")}>Add Task</button>
    </form>
    </>
}*/

  /*
  class todoForm extends React.Component<{taskiditem?:string}>=({taskiditem=this.state('taskiditem')})=> {

    handleChange = event => {
        this.setState({taskiditem: event.target.value});
    };

    render(){
      return (<React.Fragment>
        <form>
            <input type="text" id="taskiditem" name="taskiditem" placeholder="Task ID" value={this.state.taskiditem onChange={this.handleChange}}></input>
            <input type="text" id="tasktextitem" name="tasktextitem" placeholder="Tasks"></input>
            <button onClick={() => alert({this.state.taskiditem})}>Add Task</button>
        </form>
      </React.Fragment>)
    }
}*/

/*
class Input extends Component {
  private _onChange = (e: React.KeyboardEvent) => {
    const name = this.props.data.Name;
    const value = (e.target as HTMLInputElement).value;
    this.props.onChange(name, value);
  }
  
  public render(): JSX.Element {
    return (
        <input
            type="text"
            value={this.props.data.Value}
            onChange={this._onChange}/>
    );
  }
}*/

  /*const AddTodoForm: React.FC = () => {
    return (
      <form>
        <img src={addLogo} alt="add_icon" width="20px"></img>
        <input type="text" id="taskiditem"/>
        <input type="text" id="tasktextitem"/>
        <input type="checkbox"/>
      </form>
    );
  }*/

  /*const TodoListItem: React.FC = () => {
    return (
      <tr>
        <td><img src={addLogo} alt="add_icon" width="20px"></img></td>
        <td>{todo.taskid}</td>
        <td>{todo.text}</td>
        <td><input type="checkbox" checked={todo.complete}></input></td>
        <td><u>Remove</u></td>
      </tr>
    );
  };

 class StatusCard extends React.Component<taskiditem,tasktextitem>{
      static defaultProps = {
        Defaulttaskiditem: "Task 1",
        Defaulttasktextitem: "Write write write"
    }

    state = {
      item_id: this.props.Defaulttaskiditem,
      item_text: this.props.Defaulttasktextitem
    }
 }*/

/*
const initialTodos: Todo[] = [
  {
    text: 'Walk the dog'
  },
  {
    text: 'Write app'
  },
];

 interface Props2 {
  todos: Todo[];
}


const AddTodoForm: React.FC<Props2> = ({todos}) => {
  const [text, setText] = useState('');

  return (
    <form>
      <input type="text" value={text} onChange={e => {setText(e.target.value);}}/>
      <button type="submit" onClick={e => {e.preventDefault(); todos(text); setText('');
        }}
      >
        Add Task
      </button>
    </form>
  );
}; */

//<input type="text" value={text} onChange={e => {setText(e.target.value);}}/>
//document.getElementById('theDiv').innerHTML('This is new.')

interface Todo {
  text: any;
  id: any;
}

/*
// our components props accept a number for the initial value
const Counter:FunctionComponent<{ initial?: number }> = ({ initial = 0 }) => {
  // since we pass a number here, clicks is going to be a number.
  // setClicks is a function that accepts either a number or a function returning
  // a number
  const [clicks, setClicks] = useState(initial);
  return <>
    <p>Clicks: {clicks}</p>
    <button onClick={() => setClicks(clicks+1)}>+</button>
    <button onClick={() => setClicks(clicks-1)}>-</button>
  </>
}*/

const TodoListItem: React.FC<{ initial?: number}> = ({initial=0}) => {
  const [taskID, setTaskID] = useState('');
  const [taskText, setTaskText] = useState('');
  const [clicks, setClicks] = useState(initial);

  return <>
    <form>
      <input type="text" id="taskiditem" name="taskiditem" placeholder="Task ID" value={taskID} onChange={e => {setTaskID(e.target.value);}}/>
      <input type="text" id="tasktextitem" name="tasktextitem" placeholder="Tasks" value={taskText} onChange={e => {setTaskText(e.target.value);}}/>
      <button type="submit" onClick={e => {e.preventDefault(); setClicks(clicks+1); setTaskID(taskID); setTaskText(taskText);  }}>
        Add Task
      </button>
    </form>
    <p>Number of Task(s): {clicks}</p>
    <br/><br/>
    <table>
    <tr>
      <th>&nbsp;</th>
      <th>Task ID</th>
      <th>Tasks</th>
      <th>Status</th>
      <th>&nbsp;</th>
    </tr>
    <tr>
        <td><img src={addLogo} alt="add_icon" width="20px"></img></td>
        <td>{setTaskID}</td>
        <td>{taskText}</td>
        <td><input type="checkbox"></input></td>
        <td><u>Remove</u></td>
      </tr>
</table>
    
  </>
};

function App() {

  return (
    <div className="App">
      <header className="App-header">
        <h1>
          <u>TASK MANAGEMENT SYSTEM</u>
        </h1>
        </header>

        <p className="App-intro">
        <br/><br/>


        
        <br/><br/>

<TodoListItem />

<br/><br/>


        
        </p>

    </div>
  );

}

export default App;
