import React from 'react';
/*
interface Todo {
  text: string;
  complete: string;
}

class TodoClass{
  text:String;
  complete:string;

  constructor (text:string,complete:string){
    this.text = text;
    this.complete = complete;
  }

} 



export const TodoListItem: React.FC<Props> = ({todo}) => {
  return (
  <li>
    <label style={{ textDecoration: todo.complete ? 'line-through' : undefined }}>
    <input type="checkbox" checked={todo.complete} /> {todo.text}
  </label>
</li>
  )
};*/